import csv
import numpy as np
import os
from sklearn.ensemble import RandomForestRegressor

base_dir = os.path.abspath('.')      #base_dir = r'C:\Users\LOY\Desktop\CFO Forecast\challenge_data'
train_file = base_dir + r'\train.csv'
test_file = base_dir + r'\test_blank.csv'
test_result_file = base_dir + r'\test_result.csv'
train_result_file = base_dir + r'\train_result.csv'
feature_importances_file = base_dir + r'\feature_importances.csv'

# get Generic Group
def get_gg(word):
    dic = {
        'Consumer' : 1,
        'Consumer Market' : 2
    }
    return dic[word]

# get Generic Brand
def get_gb(word):
    dic = {
        'Sandesh Brand 1' : 1,
        'Sandesh Brand 2' : 2,
        'Sandesh Brand 3' : 3,
        'Non Sandesh Brand 4' : 4,
        'Non Sandesh Brand 5' : 5,
        'Non Sandesh Brand 8' : 6,
        'Non Sandesh Brand 9' : 7,
        'Non Sandesh Brand 10' : 8,
        'Market' : 9,
        'Sandesh Brand 1  and Non Sandesh Brand 4 ' : 10,
        'Sandesh Brand 1 and Market' : 11
    }
    return dic[word]

# get Generic Product
def get_gp(word):
    dic = {
        'Cheetah' : 1,
        'Falcon' : 2,
        'Overall' : 3,
        'Rabbit' : 4,
        'Tortoise' : 5,
        'All' : 6, 'Total across Products' : 6,
        'Rabbit + Cheetah' : 7
    }
    return dic[word]

def get_gv(word):
    dic = {
        'gross adds': 1,
        'leavers': 2,
        'migrations': 3,
        'revenue': 4,

        'net adds': 5,
        'closing base': 6,
        'opening base' : 7,
        'immigration': 8,
        'tv adoption': 9,
        'tv proposition' : 10,
        'tv': 11,
        'households': 12,
        'switchers': 13,
        'win ratio': 14,
        'number of customer who finished their contract each month': 15,
        'brand nps at product level': 16,
        'acquisition price': 17,
        'broadband awareness': 18, 'broadband direct' : 18,
        'footprint': 19,
        'complaints': 20,
        'total addressable market': 21,
        'total marketing spend': 22,
        'brand': 23
    }

    for key in dic:
        if key in word.lower():
            return dic[key]

# get Time Period
tp_dic = {}
def get_tp(word):
    dic = {
        'Q1_Apr': 1,
        'Q1_May': 2,
        'Q1_Jun': 3, 'Q2_Jun': 3,
        'Q2_Jul': 4,
        'Q2_Aug': 5,
        'Q2_Sep': 6,
        'Q3_Oct': 7,
        'Q3_Nov': 8,
        'Q3_Dec': 9,
        'Q4_Jan': 10,
        'Q4_Feb': 11,
        'Q4_Mar': 12,
    }

    #09/10_Q1_Aug
    y1 = int(word[0:2])
    qm = word[6:12]

    if y1 < 11:
        return -1
    tp = (y1 - 11) * 12 + dic[qm]
    if not tp in tp_dic:
        tp_dic[tp] = word
    return tp

max_gb = 11
max_gp = 7
max_gv = 23
max_tp = get_tp('19/20_Q1_Jun')

class Record:
    #row data
    gg = None
    gb = None
    gp = None
    gv = None
    tp = None
    v = None
    row = None

    v_in_last_tp = None
    v_inc = None
    features = None

    predict_v_inc = None
    predict_v = None

    def __init__(self):
        self.features = []

def read_csv(file, train_flag):
    records = []
    with open(file, 'r') as f:
        reader = csv.reader(f, delimiter=',')
        next(reader)
        for row in reader:
            r = Record()
            r.gg = get_gg(row[0])
            r.gb = get_gb(row[1])
            r.gp = get_gp(row[3])
            r.gv = get_gv(row[5])
            r.tp = get_tp(row[8])
            r.row = ','.join(row)
            if r.tp == -1:    # ignore the data before 11/12
                continue
            if train_flag:
                r.v = float(row[9])
            records.append(r)
    return records

def build_values(train_records):
    # init
    vs = np.zeros((max_tp + 1, max_gb + 1, max_gp + 1, max_gv + 1))
    for tp in range(0, max_tp + 1):
        for gb in range(1, max_gb + 1):
            for gp in range(1, max_gp + 1):
                for gv in range(1, max_gv + 1):
                    vs[tp, gb, gp, gv] = None

    # set value
    for r in train_records:
        vs[r.tp, r.gb, r.gp, r.gv] = r.v

    # 'Sandesh Brand 1  and Non Sandesh Brand 4 '
    for tp in range(0, max_tp + 1):
        for gp in range(1, max_gp + 1):
            for gv in range(1, max_gv + 1):
                if np.isnan(vs[tp, 10, gp, gv]) and not np.isnan(vs[tp, 1, gp, gv]) and not np.isnan(vs[tp, 4, gp, gv]):
                    vs[tp, 10, gp, gv] = vs[tp, 1, gp, gv] + vs[tp, 4, gp, gv]

    # Rabbit + Cheetah
    for tp in range(0, max_tp + 1):
        for gb in range(1, max_gb + 1):
            for gv in range(1, max_gv + 1):
                if np.isnan(vs[tp, gb, 7, gv]) and not np.isnan(vs[tp, gb, 1, gv]) and not np.isnan(vs[tp, gb, 4, gv]):
                    vs[tp, gb, 7, gv] = vs[tp, gb, 1, gv] + vs[tp, gb, 4, gv]

    # fill nan with value of last month
    for tp in range(0, max_tp + 1):
        for gb in range(1, max_gb + 1):
            for gp in range(1, max_gp + 1):
                for gv in range(1, max_gv + 1):
                    if tp == 0:
                        vs[tp, gb, gp, gv] = np.nan
                    elif np.isnan(vs[tp, gb, gp, gv]):
                        vs[tp, gb, gp, gv] = vs[tp - 1, gb, gp, gv]

    return vs

def build_values_inc(vs):
    vs_inc = np.zeros((max_tp + 1, max_gb + 1, max_gp + 1, max_gv + 1))
    for tp in range(1, max_tp + 1):
        for gb in range(1, max_gb + 1):
            for gp in range(1, max_gp + 1):
                for gv in range(1, max_gv + 1):
                    if np.isnan(vs[tp, gb, gp, gv]) or np.isnan(vs[tp - 1, gb, gp, gv]):
                        vs_inc[tp, gb, gp, gv] = 0
                    else:
                        vs_inc[tp, gb, gp, gv] = vs[tp, gb, gp, gv] - vs[tp - 1, gb, gp, gv]
    return vs_inc

def check_nan(v):
    if np.isnan(v):
        return 0
    return v

# get features
def get_features(record, vs, vs_inc):
    r_tp = record.tp
    r_gb = record.gb
    r_gp = record.gp
    r_gv = record.gv

    features = []
    for gv in range(1, max_gv + 1):
        features.append(check_nan(vs[r_tp - 1, r_gb, r_gp, gv]))

    for gv in range(1, max_gv + 1):
        features.append(check_nan(vs_inc[r_tp - 1, r_gb, r_gp, gv]))

    for gv in range(1, max_gv + 1):
        features.append((check_nan(vs_inc[r_tp - 1, r_gb, r_gp, gv]) + check_nan(vs_inc[r_tp - 2, r_gb, r_gp, gv])+ check_nan(vs_inc[r_tp - 3, r_gb, r_gp, gv]))/3)

    return features

def array_to_str(arr):
    s = ''
    for i in range(len(arr)):
        if i != 0:
            s += ','
        s += str(arr[i])
    return s

# read raw data
train_records = read_csv(train_file, True)
test_records = read_csv(test_file, False)
all_records = []
all_records.extend(train_records)
all_records.extend(test_records)

# build values
vs = build_values(train_records)

# build increased values(compared to last month)
vs_inc = build_values_inc(vs)

# set v_in_last_tp, v_inc
for record in all_records:
    record.v_in_last_tp = check_nan(vs[record.tp - 1, record.gb, record.gp, record.gv])
    record.v_inc = check_nan(vs_inc[record.tp, record.gb, record.gp, record.gv])

# get features
for record in all_records:
    record.features = get_features(record, vs, vs_inc)

feature_importances_dic = {}
start_tp = get_tp('16/17_Q4_Mar')
for tp in range(start_tp, max_tp + 1):
    print("start tp:", tp_dic[tp])
    records_by_tp = list(filter(lambda x: x.tp == tp, all_records))
    rfs = {}
    for record in records_by_tp:
        no_records_for_train = False
        if not record.gv in rfs:
            # build RF for gv
            records_for_train = list(filter(lambda x: x.tp in range(tp - 48, tp) and x.gv == record.gv, train_records))
            if len(records_for_train) == 0:
                no_records_for_train = True
            else:
                X_train = [r.features for r in records_for_train]
                y = [r.v_inc for r in records_for_train]
                rf = RandomForestRegressor(n_estimators = 200, max_features = 10, min_samples_split = 11, n_jobs = 8, random_state = 1)
                rf.fit(X_train, y)
                rfs[record.gv] = rf

            if not record.gv in feature_importances_dic:
                feature_importances_dic[record.gv] = []
            feature_importances_dic[record.gv].append(rf.feature_importances_)

        if no_records_for_train:
            record.predict_v_inc = 0
        else:
            rf = rfs[record.gv]
            X_test = [record.features]
            record.predict_v_inc = rf.predict(X_test)[0]

        if np.isnan(record.v_in_last_tp):
            record.predict_v = record.predict_v_inc
        else:
            record.predict_v = record.predict_v_inc + record.v_in_last_tp

# output train results
scores = np.zeros(max_gv + 1)
base_scores = np.zeros(max_gv + 1)
nums = np.zeros(max_gv + 1, dtype = int)

if os.path.exists(train_result_file):
    os.remove(train_result_file)
with open(train_result_file, 'a') as f:
    for record in train_records:
        if record.tp >= start_tp:
            scores[record.gv] += max(0, 1 - abs(record.v_in_last_tp + record.predict_v_inc - record.v) / abs(record.v))
            base_scores[record.gv] += max(0, 1 - abs(record.v_in_last_tp - record.v) / abs(record.v))
            nums[record.gv] += 1
            f.write('{0},{1},{2},{3},{4},{5},{6},{7}\n'.format(record.tp, record.gb, record.gp, record.gv, record.v_inc, record.predict_v_inc, record.v, record.predict_v))
    for gv in range(1, max_gv + 1):
        if nums[gv] > 0:
            print('gv_{0}: num = {1}, avg_score = {2}, avg_base_score = {3}'.format(gv, nums[gv], scores[gv] / nums[gv] * 100, base_scores[gv] / nums[gv] * 100))
    print('gv_all: num = {0}, avg_score = {1}, avg_base_score = {2}'.format(np.sum(nums), np.sum(scores) / np.sum(nums) * 100, np.sum(base_scores) / np.sum(nums) * 100))

# output feature importances
if os.path.exists(feature_importances_file):
    os.remove(feature_importances_file)
with open(feature_importances_file, 'a') as f:
    for gv in range(1, max_gv + 1):
        if gv in feature_importances_dic:
            feature_importances = np.mean(feature_importances_dic[gv], 0)
            f.write('{0},{1}\n'.format(gv, array_to_str(feature_importances)))

# output predict results
if os.path.exists(test_result_file):
    os.remove(test_result_file)
with open(test_result_file, 'a') as f:
    f.write('Generic Group,Generic Brand,Generic Product Category,Generic Product,Variable Group,Generic Variable,Generic LookupKey,Units,Time Period,Value\n')
    for record in test_records:
        f.write('{0},{1}\n'.format(record.row, record.predict_v))

