import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from tqdm import tqdm_notebook as tqdm

from sklearn.linear_model import Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import ParameterGrid
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import shap

from utils import correct_dates_df


def pipeline(X_train, y_train, X_val, y_val, params):
    """
    Fit pipeline with given hyperparameters and make predictions for test.
    :param X_train: np.array or pd.DataFrame, Train features
    :param y_train: np.array, Train targets
    :param X_val: np.array or pd.DataFrame, Validation features
    :param y_val: np.array, Validation targets
    :param params: dict with hyperparameters
    :return:
    """
    # select how many points to take for preds
    X_train = X_train[-params["train_points"]:]
    y_train = y_train[-params["train_points"]:]

    # scale
    if params["scale"] == "None":
        X_train_scaled = X_train
        X_val_scaled = X_val
    if params["scale"] == "MinMax":
        sclaer = MinMaxScaler()
        X_train_scaled = sclaer.fit_transform(X_train)
        X_val_scaled = sclaer.transform(X_val)
    if params["scale"] == "Standard":
        sclaer = StandardScaler()
        X_train_scaled = sclaer.fit_transform(X_train)
        X_val_scaled = sclaer.transform(X_val)

    # model
    if params["model"] == "lr":
        model = Ridge(random_state=42)
    if params["model"] == "rf":
        model = RandomForestRegressor(n_estimators=120, random_state=42, n_jobs=-1)
    if params["model"] == "lasso":
        model = Lasso(random_state=42)

    model.fit(X_train_scaled, y_train)
    y_hat_val = model.predict(X_val_scaled)

    y_val, y_hat = np.array(y_val), np.array(y_hat_val)
    score = np.mean(abs((y_val - y_hat_val) / y_val) * 100)
    return score, list(y_hat_val)


def gs_model_predict(X: pd.DataFrame, y: np.array, val_points=12, pred_step=1, verbose=True):
    """
    Split data into train, val and test. Run grid search and make predictions with best model.
    :param X: pd.DataFrame, Full dataset with features
    :param y: np.array, Targets
    :param val_points: int, number of points in validation
    :param pred_step: int, prediction horizon
    :param verbose: bool, show intermediate records
    :return:
    """
    # make split
    y_train = y.shift(-pred_step)[:-pred_step].copy()
    X_train = X[:-pred_step].copy()
    X_test = X[-1:].copy()

    X_val = X_train[-val_points:].fillna(0)
    y_val = y_train[-val_points:].fillna(0)
    X_train = X_train[:-val_points].fillna(0)
    y_train = y_train[:-val_points].fillna(0)
    if verbose:
        print("Train, val, test shapes:")
        print(X_train.shape, X_val.shape, X_test.shape)

    # search for best model
    #grid = {
    #    "train_points": [999, 24, 48, 72],  # 999 stands for all points
    #    "scale": ["None", "MinMax", "Standard"],
    #    "model": ["lr", "rf"]
    #}
    # parameters_list = list(ParameterGrid(grid))
    parameters_list = [
        # LR
        {"train_points": 24, "scale": "None", "model": "lr"},
        {"train_points": 48, "scale": "None", "model": "lr"},
        {"train_points": 999, "scale": "None", "model": "lr"},
        {"train_points": 48, "scale": "MinMax", "model": "lr"},
        {"train_points": 48, "scale": "Standard", "model": "lr"},

        # RF
        {"train_points": 999, "scale": "None", "model": "rf"},
        {"train_points": 72, "scale": "None", "model": "rf"},
        {"train_points": 48, "scale": "None", "model": "rf"},

        # lasso
        {"train_points": 12, "scale": "None", "model": "lasso"},
    ]

    scores = []
    for param in parameters_list:
        score, _ = pipeline(X_train, y_train, X_val, y_val, param)
        scores.append(score)
    ind = np.argmin(scores)
    best_score, best_params = scores[ind], parameters_list[ind]

    if verbose:
        print(f"Prediction for step : {pred_step}")
        print(f"MAPE : {np.round(best_score, 2)} %")
        print("\n\n")

    # refit with all train data and make prediction
    y_train = y.shift(-pred_step)[:-pred_step].copy()
    X_train = X[:-pred_step].copy()
    _, best_pred = pipeline(X_train, y_train, X_test, [1], best_params)
    return best_score, list(best_pred)


def process_train(train_path: str):
    """
    Process train dataframe into useful format
    :param train_path: str, path to train data
    :return:
    """
    train = pd.read_csv(train_path)
    train = correct_dates_df(train)
    train_piv = train.pivot(index="Time Period", columns="Generic LookupKey", values="Value")

    # fill missing values
    train_piv = train_piv.interpolate().fillna(method="ffill").fillna(method="bfill")

    # create features
    storage = []

    # prev value
    temp = train_piv.copy()
    temp.columns = [f"{col}_prev_value" for col in train_piv.columns]
    storage.append(temp)

    # shift features
    for s in [1, 2, 3, 6, 12]:
        temp = train_piv.shift(s).copy()
        temp.columns = [f"{col}_shift_{s}" for col in train_piv.columns]
        storage.append(temp)
        
    # delta features
    for d in [1, 2, 3, 6, 12]:
        temp = (train_piv - train_piv.shift(d)).copy()
        temp.columns = [f"{col}_delta_{d}" for col in train_piv.columns]
        storage.append(temp)

    # combine features into single dataframe
    X = pd.concat(storage, axis=1).fillna(0)
    y = train_piv.loc[X.index].fillna(0)
    return X, y


def fit_predict(train_path: str, predictions_path: str, predict_targets: list,
                val_steps=12, predict_horizon=4, verbose=True):
    """
    Make predictions for given variables
    :param train_path: str, path to train dataframe
    :param predictions_path: str, path to save predictions
    :param predict_targets: list of str, names of variables in train dataframe to predict
    :param val_steps: int, number of points in validation
    :param predict_horizon: int, predict horizon for targets
    :param verbose: bool, show intermediate records
    :return:
    """
    X, y = process_train(train_path)

    print(f"Length of train data : {y.shape[0]}")
    if predict_horizon > y.shape[0]:
        print("Predict horizon is larger than train length. Could not predict. Try smaller values for horizon.")

    # sanity check
    target_cols_not_in_train = [col for col in predict_targets if col not in y.columns]
    if len(target_cols_not_in_train):
        for col in target_cols_not_in_train:
            print(f"Target column : '{col}' is not in train data. Could not predict")
            predict_targets.remove(col)
    print(f"Making predictions for : {len(predict_targets)} targets")

    # grid search best model and make predictions
    df_predictions = pd.DataFrame({})
    cols_scores = []
    for col in tqdm(predict_targets):
        print(f"\n\nPredicting {col}")
        preds = []
        scores = []
        for step in range(1, predict_horizon+1):
            score, pred = gs_model_predict(X, y[col], val_points=val_steps, pred_step=step, verbose=verbose)
            preds += pred
            scores.append(score)
        df_predictions[col] = preds
        cols_scores.append(np.mean(scores))
    df_scores = pd.DataFrame({"target": predict_targets, "MAPE, %": np.round(cols_scores, 2)})

    # save predictions
    df_predictions.to_csv(os.path.join(predictions_path, "test_predictions.csv"), index=False)
    df_scores.to_csv(os.path.join(predictions_path, "validation_scores.csv"), index=False)
    print(f"Test predictions and validation scores are saved to {predictions_path}")
    return df_predictions


def explain(train_path: str, explain_targets: list, top_important=10):
    """
    Explain models with SHAP values and coefficients of linear model
    :param train_path: str, path to train dataframe
    :param explain_targets: list of str, names of variables in train dataframe to explain
    :param top_important: int, how many important variables to show
    :return:
    """
    X, y = process_train(train_path)

    last_points, step = 72, 1
    y = y.shift(-step)[-last_points:-step].copy()
    X = X[-last_points:-step].copy()

    # sanity check
    target_cols_not_in_train = [col for col in explain_targets if col not in y.columns]
    if len(target_cols_not_in_train):
        for col in target_cols_not_in_train:
            print(f"Target column : '{col}' is not in train data. Could not explain")
            explain_targets.remove(col)
    print("Making explanation for : ")
    print(explain_targets)
    print("\n\n\n")

    for col in explain_targets:
        print(f"Important features for {col}")
        # fit simple LR model to predict next value
        lr = Ridge(random_state=42)
        lr.fit(X, y[col])

        # SHAP importance for explaining
        explainer = shap.LinearExplainer(lr, data=X)
        shap_values = explainer.shap_values(X)
        shap.summary_plot(shap_values, X, max_display=top_important)
        plt.show()

        # abs influence
        print("Abs influence on target variable : ")
        sorted_ind = np.argsort(-abs(lr.coef_))
        for ind in sorted_ind[:top_important]:
            print(X.columns[ind], "--->", np.round(lr.coef_[ind], 6))
        print("-"*100)
        print("\n\n")